/*
               File: GAM_ChangeRepository
        Description: Change repository
             Author: GeneXus C# Generator version 17_0_2-148565
       Generated on: 3/5/2021 11:40:22.85
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_changerepository', false, function () {
   this.ServerClass =  "gam_changerepository" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e121l2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e141l2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24];
   this.GXLastCtrlId =24;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE3",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"TABLE1",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id:19 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSELECTEDCONNECTION",gxz:"ZV12SelectedConnection",gxold:"OV12SelectedConnection",gxvar:"AV12SelectedConnection",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"radio",v2v:function(Value){if(Value!==undefined)gx.O.AV12SelectedConnection=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12SelectedConnection=Value},v2c:function(){gx.fn.setRadioValue("vSELECTEDCONNECTION",gx.O.AV12SelectedConnection);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12SelectedConnection=this.val()},val:function(){return gx.fn.getControlValue("vSELECTEDCONNECTION")},nac:gx.falseFn};
   this.declareDomainHdlr( 19 , function() {
   });
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"CONFIRM",grid:0,evt:"e121l2_client",std:"ENTER"};
   this.AV12SelectedConnection = "" ;
   this.ZV12SelectedConnection = "" ;
   this.OV12SelectedConnection = "" ;
   this.AV12SelectedConnection = "" ;
   this.Events = {"e121l2_client": ["ENTER", true] ,"e141l2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{ctrl:'vSELECTEDCONNECTION'},{av:'AV12SelectedConnection',fld:'vSELECTEDCONNECTION',pic:''}],[{ctrl:'vSELECTEDCONNECTION'},{av:'AV12SelectedConnection',fld:'vSELECTEDCONNECTION',pic:''}]];
   this.EvtParms["START"] = [[{ctrl:'vSELECTEDCONNECTION'},{av:'AV12SelectedConnection',fld:'vSELECTEDCONNECTION',pic:''}],[{ctrl:'vSELECTEDCONNECTION'},{av:'AV12SelectedConnection',fld:'vSELECTEDCONNECTION',pic:''}]];
   this.EvtParms["ENTER"] = [[{ctrl:'vSELECTEDCONNECTION'},{av:'AV12SelectedConnection',fld:'vSELECTEDCONNECTION',pic:''}],[{ctrl:'vSELECTEDCONNECTION'},{av:'AV12SelectedConnection',fld:'vSELECTEDCONNECTION',pic:''}]];
   this.EnterCtrl = ["CONFIRM"];
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_changerepository);});
