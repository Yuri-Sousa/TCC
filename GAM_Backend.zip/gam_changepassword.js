/*
               File: GAM_ChangePassword
        Description: Change password
             Author: GeneXus C# Generator version 17_0_2-148565
       Generated on: 3/5/2021 11:39:29.69
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_changepassword', false, function () {
   this.ServerClass =  "gam_changepassword" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV15IDP_State=gx.fn.getControlValue("vIDP_STATE") ;
   };
   this.e120l2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e130l2_client=function()
   {
      /* 'Login' Routine */
      return this.executeServerEvent("'LOGIN'", true, null, false, false);
   };
   this.e150l2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34];
   this.GXLastCtrlId =34;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TABLE1",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",gxz:"ZV11UserName",gxold:"OV11UserName",gxvar:"AV11UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV11UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id:20 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORD",gxz:"ZV12UserPassword",gxold:"OV12UserPassword",gxvar:"AV12UserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12UserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12UserPassword=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORD",gx.O.AV12UserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12UserPassword=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 20 , function() {
   });
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORDNEW",gxz:"ZV13UserPasswordNew",gxold:"OV13UserPasswordNew",gxvar:"AV13UserPasswordNew",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13UserPasswordNew=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13UserPasswordNew=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORDNEW",gx.O.AV13UserPasswordNew,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13UserPasswordNew=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORDNEW")},nac:gx.falseFn};
   this.declareDomainHdlr( 24 , function() {
   });
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id:28 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORDNEWCONF",gxz:"ZV14UserPasswordNewConf",gxold:"OV14UserPasswordNewConf",gxvar:"AV14UserPasswordNewConf",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14UserPasswordNewConf=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14UserPasswordNewConf=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORDNEWCONF",gx.O.AV14UserPasswordNewConf,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14UserPasswordNewConf=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORDNEWCONF")},nac:gx.falseFn};
   this.declareDomainHdlr( 28 , function() {
   });
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"BTNCONFIRM",grid:0,evt:"e120l2_client",std:"ENTER"};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"BTNBACK", format:0,grid:0,evt:"e130l2_client", ctrltype: "textblock"};
   this.AV11UserName = "" ;
   this.ZV11UserName = "" ;
   this.OV11UserName = "" ;
   this.AV12UserPassword = "" ;
   this.ZV12UserPassword = "" ;
   this.OV12UserPassword = "" ;
   this.AV13UserPasswordNew = "" ;
   this.ZV13UserPasswordNew = "" ;
   this.OV13UserPasswordNew = "" ;
   this.AV14UserPasswordNewConf = "" ;
   this.ZV14UserPasswordNewConf = "" ;
   this.OV14UserPasswordNewConf = "" ;
   this.AV11UserName = "" ;
   this.AV12UserPassword = "" ;
   this.AV13UserPasswordNew = "" ;
   this.AV14UserPasswordNewConf = "" ;
   this.AV15IDP_State = "" ;
   this.Events = {"e120l2_client": ["ENTER", true] ,"e130l2_client": ["'LOGIN'", true] ,"e150l2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV15IDP_State',fld:'vIDP_STATE',pic:'',hsh:true}],[]];
   this.EvtParms["START"] = [[],[{av:'AV11UserName',fld:'vUSERNAME',pic:''}]];
   this.EvtParms["ENTER"] = [[{av:'AV13UserPasswordNew',fld:'vUSERPASSWORDNEW',pic:''},{av:'AV14UserPasswordNewConf',fld:'vUSERPASSWORDNEWCONF',pic:''},{av:'AV12UserPassword',fld:'vUSERPASSWORD',pic:''},{av:'AV15IDP_State',fld:'vIDP_STATE',pic:'',hsh:true}],[]];
   this.EvtParms["'LOGIN'"] = [[],[]];
   this.EnterCtrl = ["BTNCONFIRM"];
   this.setVCMap("AV15IDP_State", "vIDP_STATE", 0, "char", 60, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_changepassword);});
