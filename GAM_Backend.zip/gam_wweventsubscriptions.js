/*
               File: GAM_WWEventSubscriptions
        Description: Event Subscriptions
             Author: GeneXus C# Generator version 17_0_2-148565
       Generated on: 3/5/2021 11:40:39.96
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wweventsubscriptions', false, function () {
   this.ServerClass =  "gam_wweventsubscriptions" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV18CountReg=gx.fn.getIntegerValue("vCOUNTREG",gx.thousandSeparator) ;
      this.AV18CountReg=gx.fn.getIntegerValue("vCOUNTREG",gx.thousandSeparator) ;
   };
   this.Validv_Status=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(23);
      return this.validCliEvt("Validv_Status", 23, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vSTATUS");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV17Status , "u" ) == 0 || gx.text.compare( this.AV17Status , "s" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Status"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Event=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(23);
      return this.validCliEvt("Validv_Event", 23, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vEVENT");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV10Event , "user-update" ) == 0 || gx.text.compare( this.AV10Event , "user-insert" ) == 0 || gx.text.compare( this.AV10Event , "user-delete" ) == 0 || gx.text.compare( this.AV10Event , "user-updateroles" ) == 0 || gx.text.compare( this.AV10Event , "user-getcustominfo" ) == 0 || gx.text.compare( this.AV10Event , "user-savecustominfo" ) == 0 || gx.text.compare( this.AV10Event , "role-insert" ) == 0 || gx.text.compare( this.AV10Event , "role-update" ) == 0 || gx.text.compare( this.AV10Event , "role-delete" ) == 0 || gx.text.compare( this.AV10Event , "repository-login" ) == 0 || gx.text.compare( this.AV10Event , "repository-loginfailed" ) == 0 || gx.text.compare( this.AV10Event , "repository-logout" ) == 0 || gx.text.compare( this.AV10Event , "application-checkprmfail" ) == 0 || gx.text.compare( this.AV10Event , "externalauthentication-response" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Event"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e112l1_client=function()
   {
      /* 'AddNew' Routine */
      this.clearMessages();
      this.call("gam_eventsubscriptionentry.aspx", ["INS", ""], null, ["Mode","Id"]);
      this.refreshOutputs([]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e142l2_client=function()
   {
      /* Description_Click Routine */
      this.clearMessages();
      this.call("gam_eventsubscriptionentry.aspx", ["DSP", this.AV14Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV14Id',fld:'vID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e152l2_client=function()
   {
      /* Btnupd_Click Routine */
      this.clearMessages();
      this.call("gam_eventsubscriptionentry.aspx", ["UPD", this.AV14Id], null, ["Mode","Id"]);
      this.refreshOutputs([{av:'AV14Id',fld:'vID',pic:''}]);
      this.OnClientEventEnd();
      return gx.$.Deferred().resolve();
   };
   this.e162l2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e172l2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,24,25,26,27,28,29,30,31,32,33,34,35];
   this.GXLastCtrlId =35;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",23,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wweventsubscriptions",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Description",24,"vDESCRIPTION",gx.getMessage( "Event Description"),"","Description","char",0,"px",254,80,"left","e142l2_client",[],"Description","Description",true,0,false,false,"Attribute SmallLink",1,"WWColumn");
   GridwwContainer.addComboBox("Status",25,"vSTATUS",gx.getMessage( "Status"),"Status","char",null,0,true,false,0,"px","WWColumn WWOptionalColumn");
   GridwwContainer.addComboBox("Event",26,"vEVENT",gx.getMessage( "Entity"),"Event","char",null,0,true,false,0,"px","WWColumn WWSecondaryColumn");
   GridwwContainer.addSingleLineEdit("Filename",27,"vFILENAME",gx.getMessage( "File Name"),"","FileName","char",0,"px",254,80,"left",null,[],"Filename","FileName",true,0,false,false,"Attribute",1,"WWColumn WWSecondaryColumn");
   GridwwContainer.addSingleLineEdit("Classname",28,"vCLASSNAME",gx.getMessage( "ClassName"),"","ClassName","char",0,"px",60,60,"left",null,[],"Classname","ClassName",true,0,false,false,"Attribute",1,"WWColumn WWOptionalColumn");
   GridwwContainer.addSingleLineEdit("Methodname",29,"vMETHODNAME",gx.getMessage( "Method Name"),"","MethodName","char",0,"px",60,60,"left",null,[],"Methodname","MethodName",true,0,false,false,"Attribute",1,"WWColumn WWOptionalColumn");
   GridwwContainer.addSingleLineEdit("Btnupd",30,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"left","e152l2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Id",31,"vID",gx.getMessage( "GUID"),"","Id","char",0,"px",40,40,"left",null,[],"Id","Id",false,0,false,false,"Attribute",1,"");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLETOP",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"ADDNEW",grid:0,evt:"e112l1_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",gxz:"ZV16Search",gxold:"OV16Search",gxvar:"AV16Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV16Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 14 , function() {
   });
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"GRIDCELL",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TABLE1",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDESCRIPTION",gxz:"ZV8Description",gxold:"OV8Description",gxvar:"AV8Description",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8Description=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8Description=Value},v2c:function(row){gx.fn.setGridControlValue("vDESCRIPTION",row || gx.fn.currentGridRowImpl(23),gx.O.AV8Description,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8Description=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDESCRIPTION",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e142l2_client"};
   GXValidFnc[25]={ id:25 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:this.Validv_Status,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTATUS",gxz:"ZV17Status",gxold:"OV17Status",gxvar:"AV17Status",ucs:[],op:[25],ip:[25],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV17Status=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17Status=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vSTATUS",row || gx.fn.currentGridRowImpl(23),gx.O.AV17Status);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17Status=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vSTATUS",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:60,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:this.Validv_Event,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEVENT",gxz:"ZV10Event",gxold:"OV10Event",gxvar:"AV10Event",ucs:[],op:[26],ip:[26],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV10Event=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Event=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vEVENT",row || gx.fn.currentGridRowImpl(23),gx.O.AV10Event);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10Event=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vEVENT",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILENAME",gxz:"ZV13FileName",gxold:"OV13FileName",gxvar:"AV13FileName",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV13FileName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13FileName=Value},v2c:function(row){gx.fn.setGridControlValue("vFILENAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV13FileName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV13FileName=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vFILENAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"char",len:60,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLASSNAME",gxz:"ZV6ClassName",gxold:"OV6ClassName",gxvar:"AV6ClassName",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6ClassName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6ClassName=Value},v2c:function(row){gx.fn.setGridControlValue("vCLASSNAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV6ClassName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6ClassName=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vCLASSNAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[29]={ id:29 ,lvl:2,type:"char",len:60,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMETHODNAME",gxz:"ZV15MethodName",gxold:"OV15MethodName",gxvar:"AV15MethodName",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV15MethodName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15MethodName=Value},v2c:function(row){gx.fn.setGridControlValue("vMETHODNAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV15MethodName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV15MethodName=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vMETHODNAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[30]={ id:30 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",gxz:"ZV5BtnUpd",gxold:"OV5BtnUpd",gxvar:"AV5BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23),gx.O.AV5BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e152l2_client"};
   GXValidFnc[31]={ id:31 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",gxz:"ZV14Id",gxold:"OV14Id",gxvar:"AV14Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV14Id=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Id=Value},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(23),gx.O.AV14Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV14Id=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vID",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",gxz:"ZV7CurrentPage",gxold:"OV7CurrentPage",gxvar:"AV7CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV7CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV7CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV7CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   this.AV16Search = "" ;
   this.ZV16Search = "" ;
   this.OV16Search = "" ;
   this.ZV8Description = "" ;
   this.OV8Description = "" ;
   this.ZV17Status = "" ;
   this.OV17Status = "" ;
   this.ZV10Event = "" ;
   this.OV10Event = "" ;
   this.ZV13FileName = "" ;
   this.OV13FileName = "" ;
   this.ZV6ClassName = "" ;
   this.OV6ClassName = "" ;
   this.ZV15MethodName = "" ;
   this.OV15MethodName = "" ;
   this.ZV5BtnUpd = "" ;
   this.OV5BtnUpd = "" ;
   this.ZV14Id = "" ;
   this.OV14Id = "" ;
   this.AV7CurrentPage = 0 ;
   this.ZV7CurrentPage = 0 ;
   this.OV7CurrentPage = 0 ;
   this.AV16Search = "" ;
   this.AV7CurrentPage = 0 ;
   this.AV8Description = "" ;
   this.AV17Status = "" ;
   this.AV10Event = "" ;
   this.AV13FileName = "" ;
   this.AV6ClassName = "" ;
   this.AV15MethodName = "" ;
   this.AV5BtnUpd = "" ;
   this.AV14Id = "" ;
   this.AV18CountReg = 0 ;
   this.Events = {"e162l2_client": ["ENTER", true] ,"e172l2_client": ["CANCEL", true] ,"e112l1_client": ["'ADDNEW'", false] ,"e142l2_client": ["VDESCRIPTION.CLICK", false] ,"e152l2_client": ["VBTNUPD.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV16Search',fld:'vSEARCH',pic:''},{av:'AV18CountReg',fld:'vCOUNTREG',pic:'ZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["START"] = [[],[{av:'AV7CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("vCURRENTPAGE","Visible")',ctrl:'vCURRENTPAGE',prop:'Visible'}]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV16Search',fld:'vSEARCH',pic:''},{av:'AV18CountReg',fld:'vCOUNTREG',pic:'ZZZZZZZZZ9',hsh:true}],[{av:'AV5BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV18CountReg',fld:'vCOUNTREG',pic:'ZZZZZZZZZ9',hsh:true},{av:'AV14Id',fld:'vID',pic:''},{av:'AV8Description',fld:'vDESCRIPTION',pic:''},{ctrl:'vSTATUS'},{av:'AV17Status',fld:'vSTATUS',pic:''},{ctrl:'vEVENT'},{av:'AV10Event',fld:'vEVENT',pic:''},{av:'AV13FileName',fld:'vFILENAME',pic:''},{av:'AV6ClassName',fld:'vCLASSNAME',pic:''},{av:'AV15MethodName',fld:'vMETHODNAME',pic:''}]];
   this.EvtParms["'ADDNEW'"] = [[],[]];
   this.EvtParms["VDESCRIPTION.CLICK"] = [[{av:'AV14Id',fld:'vID',pic:''}],[{av:'AV14Id',fld:'vID',pic:''}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'AV14Id',fld:'vID',pic:''}],[{av:'AV14Id',fld:'vID',pic:''}]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV16Search',fld:'vSEARCH',pic:''},{av:'AV18CountReg',fld:'vCOUNTREG',pic:'ZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV16Search',fld:'vSEARCH',pic:''},{av:'AV18CountReg',fld:'vCOUNTREG',pic:'ZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV16Search',fld:'vSEARCH',pic:''},{av:'AV18CountReg',fld:'vCOUNTREG',pic:'ZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{ctrl:'GRIDWW',prop:'Rows'},{av:'AV16Search',fld:'vSEARCH',pic:''},{av:'AV18CountReg',fld:'vCOUNTREG',pic:'ZZZZZZZZZ9',hsh:true}],[]];
   this.EvtParms["VALIDV_STATUS"] = [[{ctrl:'vSTATUS'},{av:'AV17Status',fld:'vSTATUS',pic:''}],[{ctrl:'vSTATUS'},{av:'AV17Status',fld:'vSTATUS',pic:''}]];
   this.EvtParms["VALIDV_EVENT"] = [[{ctrl:'vEVENT'},{av:'AV10Event',fld:'vEVENT',pic:''}],[{ctrl:'vEVENT'},{av:'AV10Event',fld:'vEVENT',pic:''}]];
   this.setVCMap("AV18CountReg", "vCOUNTREG", 0, "int", 10, 0);
   this.setVCMap("AV18CountReg", "vCOUNTREG", 0, "int", 10, 0);
   this.setVCMap("AV18CountReg", "vCOUNTREG", 0, "int", 10, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[14]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV18CountReg"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[14]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV18CountReg"});
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_wweventsubscriptions);});
